import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useState } from "react";
import "./App.css";

function Loja({ produtos, adicionarAoCarrinho }) {
  return (
    <main>
      <h2 className="lista">Lista de Produtos</h2>

      <Link to="/carrinho">
        <button
          className="limpar"
          style={{
            marginBottom: "1rem",
            color: "white",
            border: "none",
            padding: "8px 12px",
            cursor: "pointer",
          }}
        >
          Ver Carrinho
        </button>
      </Link>

      <div className="produtos">
        {produtos.map((p) => (
          <article key={p.id} className="produto">
            <img alt={p.nome} src={p.img} />
            <div className="produto-info">
              <span className="nome">{p.nome}</span>
              <span className="avaliacao">{"⭐".repeat(p.avaliacao)}</span>
              <span className="valor">R$ {p.valor}</span>
            </div>
            <div className="acoes">
              <button onClick={() => adicionarAoCarrinho(p)}>Comprar</button>
            </div>
          </article>
        ))}
      </div>
    </main>
  );
}

function Carrinho({ carrinho, removerDoCarrinho, limparCarrinho }) {
  const total = carrinho.reduce((soma, item) => soma + item.valor, 0);

  return (
    <main>
      <h2>Carrinho</h2>

      <div className="carrinho">
        <h3>Itens: {carrinho.length}</h3>
        <h4>Total: R$ {total}</h4>

        {carrinho.length === 0 && <p>Nenhum item no carrinho 😢</p>}

        {carrinho.map((item, index) => (
          <div key={index} className="carrinho-item">
            <img className="item-img" src={item.img} alt={item.nome} />
            <div className="valor-produto">
              <span>{item.nome}</span>
              <span>R$ {item.valor}</span>
            </div>
            <div className="delete">
              <button onClick={() => removerDoCarrinho(item.id)}>Excluir</button>
            </div>
          </div>
        ))}

        {carrinho.length > 0 && (
          <button
            className="limpar"
            style={{
              color: "white",
              border: "none",
              padding: "8px 12px",
              cursor: "pointer",
            }}
            onClick={limparCarrinho}
          >
            Limpar
          </button>
        )}
      </div>

      <Link to="/">
       <button className="botao-voltar">
          Voltar à Loja
        </button>
      </Link>
    </main>
  );
}

export default function App() {
  const [carrinho, setCarrinho] = useState([]);

  const produtos = [
    { id: 1, nome: "prod 1", valor: 100, avaliacao: 4, img: "https://placehold.co/300x200/black/white/png/?text=prod 1" },
    { id: 2, nome: "prod 2", valor: 100, avaliacao: 5, img: "https://placehold.co/300x200/black/white/png/?text=prod 2" },
    { id: 3, nome: "prod 3", valor: 80, avaliacao: 5, img: "https://placehold.co/300x200/black/white/png/?text=prod 3" },
    { id: 4, nome: "prod 4", valor: 10, avaliacao: 4, img: "https://placehold.co/300x200/black/white/png/?text=prod 4" },
    { id: 5, nome: "prod 5", valor: 120, avaliacao: 3, img: "https://placehold.co/300x200/black/white/png/?text=prod 5" },
    { id: 6, nome: "prod 6", valor: 80, avaliacao: 3, img: "https://placehold.co/300x200/black/white/png/?text=prod 6" },
  ];

  function adicionarAoCarrinho(produto) {
    setCarrinho((anterior) => [...anterior, produto]);
    console.log("Carrinho atual:", carrinho);
  }

  function removerDoCarrinho(id) {
    setCarrinho((anterior) => anterior.filter((item) => item.id !== id));
  }

  function limparCarrinho() {
    setCarrinho([]);
  }

  return (
    <Router>
      <header>
        <h1>Minha Loja</h1>
      </header>

      <Routes>
        <Route
          path="/"
          element={<Loja produtos={produtos} adicionarAoCarrinho={adicionarAoCarrinho} />}
        />
        <Route
          path="/carrinho"
          element={
            <Carrinho
              carrinho={carrinho}
              removerDoCarrinho={removerDoCarrinho}
              limparCarrinho={limparCarrinho}
            />
          }
        />
      </Routes>

      <footer>Direitos Autorais.2025.</footer>
    </Router>
  );
}
