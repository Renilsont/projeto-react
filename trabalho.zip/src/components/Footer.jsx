function Footer() {
    return (
        <footer>
            <p>Diteiros autorais 2025</p>
        </footer>
    );
}

export default Footer;